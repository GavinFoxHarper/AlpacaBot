# === test_laef_system.py - System Validation Script ===

import os
import logging
import pandas as pd
import numpy as np
from datetime import datetime

# Test all unified components - using available imports only
try:
    from config import STRATEGIES, INITIAL_CAPITAL, STOP_LOSS_PERCENT
    from core.technical_indicators import calculate_all_indicators
    from training.q_learning_agent import LAEFAgent
    from core.portfolio_manager import FIFOPortfolio
    from trading.unified_trading_engine import DualModelTradingEngine
    from data.market_data_fetcher import fetch_stock_data
except ImportError as e:
    print(f"Import warning: {e}")
    # Use yfinance as fallback
    import yfinance as yf

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

class LAEFSystemTester:
    """
    Comprehensive system tester to validate all components work together.
    """
    
    def __init__(self):
        self.test_results = {}
        self.portfolio = FIFOPortfolio(initial_cash=10000)  # Small test portfolio
        
        print("🔧 LAEF System Validation Starting...")
        print("=" * 50)
    
    def run_all_tests(self):
        """Run comprehensive system tests."""
        try:
            # Test 1: Configuration
            self.test_configuration()
            
            # Test 2: Data Pipeline
            self.test_data_pipeline()
            
            # Test 3: Indicator Calculation
            self.test_indicator_calculation()
            
            # Test 4: State Vector Creation
            self.test_state_vector_creation()
            
            # Test 5: ML Agent
            self.test_ml_agent()
            
            # Test 6: FIFO Portfolio
            self.test_fifo_portfolio()
            
            # Test 7: Trading Logic
            self.test_trading_logic()
            
            # Test 8: Full Integration
            self.test_full_integration()
            
            # Print summary
            self.print_test_summary()
            
        except Exception as e:
            logging.error(f"System test failed: {e}")
            return False
        
        return True
    
    def test_configuration(self):
        """Test that configuration is properly set up."""
        print("\n📋 Testing Configuration...")
        
        try:
            # Check required config values that exist
            assert INITIAL_CAPITAL > 0, f"INITIAL_CAPITAL should be positive, got {INITIAL_CAPITAL}"
            assert STOP_LOSS_PERCENT > 0, f"STOP_LOSS_PERCENT should be positive, got {STOP_LOSS_PERCENT}"
            assert len(STRATEGIES) > 0, f"STRATEGIES should not be empty, got {len(STRATEGIES)}"
            
            print("✅ Configuration test passed")
            self.test_results['configuration'] = True
            
        except Exception as e:
            print(f"❌ Configuration test failed: {e}")
            self.test_results['configuration'] = False
    
    def test_data_pipeline(self):
        """Test data fetching and cleaning."""
        print("\n📊 Testing Data Pipeline...")
        
        try:
            # Test data fetching
            df = fetch_stock_data('AAPL', interval='5m', period='5d')
            
            if df is None:
                raise ValueError("Data fetch returned None")
            
            if len(df) < 20:
                raise ValueError(f"Insufficient data: {len(df)} rows")
            
            # Check required columns
            required_cols = ['open', 'high', 'low', 'close', 'volume']
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                raise ValueError(f"Missing columns: {missing_cols}")
            
            print(f"✅ Data pipeline test passed - {len(df)} rows fetched")
            self.test_results['data_pipeline'] = True
            return df
            
        except Exception as e:
            print(f"❌ Data pipeline test failed: {e}")